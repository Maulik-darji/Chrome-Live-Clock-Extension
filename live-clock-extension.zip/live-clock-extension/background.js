chrome.runtime.onInstalled.addListener(() => {
    console.log('Clock extension installed!');
    // Set default value for clockEnabled
    chrome.storage.sync.set({ clockEnabled: false }, () => {
        console.log('Default clockEnabled set to false');
    });
});
