document.getElementById('enableClock').addEventListener('click', () => {
    chrome.storage.sync.set({ clockAdded: true }, () => {
        alert('Clock widget enabled! open new tab');
        window.close(); // Close the popup
    });
});

document.getElementById('disableClock').addEventListener('click', () => {
    chrome.storage.sync.set({ clockAdded: false }, () => {
        alert('Clock widget disabled! open new tab');
        window.close(); // Close the popup
    });
});
