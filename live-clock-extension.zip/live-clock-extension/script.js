function updateClock() {
  const now = new Date();
  const clockElement = document.getElementById('clock');
  clockElement.textContent = now.toLocaleTimeString();
}

setInterval(updateClock, 1000); // Update clock every second
updateClock(); // Initial call to set the clock immediately

chrome.storage.sync.get(['clockAdded'], (result) => {
  if (!result.clockAdded) {
      document.querySelector('.clock-container').style.display = 'none';
  }
});
